import React, { Component } from "react";
import PropTypes from "prop-types";
import "./Map.scss";

class Map extends Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            <div className="Map">
            </div>
        );
    }
}

Map.propTypes = {};

export default Map;
